# Code - Unexpected Maker - ESP32-S3 Boards 
Code examples and helper libraries for for ESP32-S3 boards

Currently includes:

## CircuitPython
- Shipping files including help and code.py

## MicroPython
- Helper library and example code

## Arduino
- A link to the Helper library and example code for the Arduino IDE, to be installed via the library manager 

You can find out more about my ESP32-S3 boards at https://esp32s3.com 

Please refer to the included license. 
