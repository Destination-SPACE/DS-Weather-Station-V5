# Schematics - Unexpected Maker - ESP32-S3 Boards 
PDF Schematics for my ESP32-S3 boards  

You can find out more about my ESP32-S3 boards at https://esp32s3.com 

Please refer to the included license. 
